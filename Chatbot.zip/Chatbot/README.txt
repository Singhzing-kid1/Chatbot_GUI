<--> ©️copyright 2019 by Veer Singh <-->

> For All Variables in  the path: \cb.py:
    r : Root Window
    t : True
    ue : User Entry
    l : Label
    be : Bot Entry
    sb : Submit Button
    bl : Bot Label
    ul : User Label
    re : Request
    res : Response

> For All Var iables in the path: \style\v.py
    title : Meaning N/A
    be_x : Bot Entry X
    be_y : Bot Entry Y 
    sbl : Submit Button Label
    bnl : Bot Name Label
    unl : User Name Label
    del_ent : Delete Entry
    c1 : Color 1
    c2 : Color 2

> To Run The Code In The Path: \cb.py, Without An Error, Run 'setup.py'.
> Ignore The .py File Named 'Add.Claculator.py'.
> To Change The Title, Bot And User Labels, And Colors Edit These Following Variables In Their
Respective Paths:

    title : \style\v.py
    bnl : \style\v.py
    unl : \style\v.py
    c1 : \style\v.py
    c2 : \style\v.py

> To Change The Favicon, Have A Square Image And Turn It Into A .ico Format Using An Online 
Converter Like 'https://favicon.io'
> To Change The Theme Go To: 'https://ttkthemes.readthedocs.io/en/docs/themes.html' And Change
The Theme Name On Line: 56.
> To Change Responses, Go To The File In The Path: \context_lib. You Can Add More For A Better
Experiance.